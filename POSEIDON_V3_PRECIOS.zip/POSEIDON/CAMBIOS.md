# Poseidón Oceanus — V3 con precios

## Qué cambió respecto a la entrega anterior
- **Claves de precio con tilde:** la página buscaba "Estándar" y tu config real trae "estandar"; así los precios nunca aparecían. Ahora «Estándar», «estandar» y «ESTANDAR» son la misma clave.
- **Precio válido = entero positivo de Stars.** 0, texto o vacío se rechazan.
- **Bloqueo en tres capas:** precios definidos + `PAYMENTS_ENABLED=true` + `BOT_INTEGRADO=true`. Por defecto todo queda bloqueado. «Gratuito» muestra "Gratis" y solo necesita `BOT_INTEGRADO`.
- **Envío al bot:** `solicitarCompra()` manda `{accion, nivel, afiliado_id}` con `sendData` (solo funciona si la app se abre desde un botón de teclado del bot). No cobra: el cobro lo crea el bot con `createInvoiceLink` (XTR, un solo ítem) y se abre con `openInvoice`.
- **Afiliado:** `start_param` solo se acepta con formato `[A-Za-z0-9_-]{1,64}`. La verificación real sigue siendo del bot.
- **Texto público sin jerga técnica:** se quitaron "por definir", "PAYMENTS_ENABLED" y el aviso de prototipo de la vista del usuario.
- **Beneficios por nivel** tomados de la maqueta aprobada (Gratuito, Estándar, Premium, VIP), con aviso de que pueden ajustarse antes del lanzamiento. CONFIRMA que son los definitivos.
- **Portada:** arte recortado de la maqueta (figura de Poseidón y tridente, sin títulos ni botones pintados) en vez de un emoji grande.
- **Peso:** de 780 KB a unos 90 KB. Se quitó la maqueta de la página pública y la imagen que no se usaba.
- Colores de la barra de Telegram, margen seguro del notch y reducción de movimiento.

## Cómo conectarlo con tu config real
Tu `poseidon_config.js` generado desde `config/.env` NO trae `BOT_INTEGRADO`. Agrégale `window.BOT_INTEGRADO = false;` y súbelo en lugar del de esta carpeta. Se pone en `true` solo cuando el bot ya lea los datos de la Mini App.

## V3 — Precios de lanzamiento y normales (por 30 días de acceso)
| Nivel | Lanzamiento | Normal (desde 2027-02-01, hora de Lima) | Lo que paga el comprador (≈ US$0.02 por Star) | Lo que recibes (≈ US$0.013 por Star) |
|---|---|---|---|---|
| Gratuito | Gratis | Gratis | — | — |
| Estándar | 175 ⭐ | 250 ⭐ | ≈ US$3.5 → US$5 | ≈ US$2.3 → US$3.3 |
| Premium | 420 ⭐ | 600 ⭐ | ≈ US$8.4 → US$12 | ≈ US$5.5 → US$7.8 |
| VIP | 1050 ⭐ | 1500 ⭐ | ≈ US$21 → US$30 | ≈ US$13.7 → US$19.5 |

- El precio de lanzamiento es ~30 % menor que el normal. El cambio ocurre solo, a las 00:00 de Lima del 1 de febrero de 2027.
- Todo vive en `poseidon_config.js` (`POSEIDON_PRICES`, `POSEIDON_PRICES_NORMAL`, `PRECIO_NORMAL_DESDE`). Para mover la fecha o subir un precio, cambias ahí y en `config/.env`.
- Si la fecha es inválida, la página muestra el precio normal. Si no hay precios normales, muestra el único que exista.
- **La página solo muestra.** El monto que se cobra lo decide el bot. Hasta que el bot lea esos mismos precios y la misma fecha, no habilites `PAYMENTS_ENABLED`.
- Los precios en dólares son estimaciones con tasas publicadas por terceros; Telegram puede cambiarlas y el comprador paga distinto según dónde compre sus Stars. Confirma en tu panel de Telegram.

## Pendiente (no declarar terminado)
- Que `core.py` reciba `web_app_data`, valide `initData` en el servidor y cree la factura en Stars.
- Precios aprobados, reparto con afiliados y verificación +18 más fuerte que la autodeclaración.
- La imagen del hero sale de un recorte de 484x192 px ampliado: para mejor nitidez conviene el arte original en alta resolución.
- Probar en Telegram real (celular y tablet). Yo solo lo validé con pruebas de código, no con un navegador.
